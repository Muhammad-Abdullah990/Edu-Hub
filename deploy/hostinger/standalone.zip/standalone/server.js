#!/usr/bin/env node

/**
 * TOOPERS COACHING - PRODUCTION SERVER FOR HOSTINGER
 * 
 * This server serves the built frontend static files and proxies
 * API requests to the bundled API server.
 */

import path from 'node:path';
import fs from 'node:fs';
import http from 'node:http';
import url from 'node:url';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));

// Load .env.production if present
try {
  const envFile = path.join(__dirname, '.env.production');
  if (fs.existsSync(envFile)) {
    const text = fs.readFileSync(envFile, 'utf-8');
    for (const line of text.split('\n')) {
      const s = line.trim();
      if (s && !s.startsWith('#') && s.includes('=')) {
        const i = s.indexOf('=');
        const k = s.slice(0, i).trim();
        let v = s.slice(i + 1).trim();
        if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
        if (!process.env[k]) process.env[k] = v;
      }
    }
  }
} catch {}

// Validate
const needed = ['DATABASE_URL', 'JWT_ACCESS_SECRET', 'JWT_REFRESH_SECRET', 'CORS_ORIGIN'];
const miss = needed.filter(v => !process.env[v]);
if (miss.length) {
  console.error('Missing env vars:', miss.join(', '));
  process.exit(1);
}

const PORT = process.env.PORT || 3000;
const API_PORT = 3001;
const FRONTEND_DIR = path.join(__dirname, 'public_html');

console.log('Starting server...');
console.log('PORT:', PORT);
console.log('Frontend:', FRONTEND_DIR);

// Start the bundled API server as a child process on internal port
import { spawn } from 'node:child_process';

const apiEntry = path.join(__dirname, 'dist', 'index.mjs');
if (!fs.existsSync(apiEntry)) {
  console.error('API bundle not found at', apiEntry);
  process.exit(1);
}

const apiProcess = spawn('node', [apiEntry], {
  cwd: __dirname,
  env: { ...process.env, PORT: String(API_PORT) },
  stdio: ['pipe', 'inherit', 'inherit'],
});

apiProcess.on('error', err => console.error('API process error:', err.message));

// Give API time to start
await new Promise(r => setTimeout(r, 2000));

// MIME types
const MIME = {
  '.html': 'text/html', '.js': 'application/javascript', '.mjs': 'application/javascript',
  '.css': 'text/css', '.json': 'application/json', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif',
  '.svg': 'image/svg+xml', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
  '.pdf': 'application/pdf', '.map': 'application/json',
};

const server = http.createServer((req, res) => {
  // CORS preflight
  if (req.method === 'OPTIONS') {
    const cors = process.env.CORS_ORIGIN || '*';
    res.writeHead(204, {
      'Access-Control-Allow-Origin': cors,
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Max-Age': '86400',
    });
    return res.end();
  }

  // API proxy
  if (req.url.startsWith('/api') || req.url === '/health' || req.url === '/ready' || req.url === '/live' || req.url === '/metrics' || req.url.startsWith('/admin/')) {
    const opts = {
      hostname: '127.0.0.1', port: API_PORT, path: req.url,
      method: req.method, headers: { ...req.headers },
    };
    delete opts.headers.host;
    delete opts.headers.connection;

    const proxy = http.request(opts, proxyRes => {
      const h = { ...proxyRes.headers };
      h['Access-Control-Allow-Origin'] = process.env.CORS_ORIGIN || '*';
      res.writeHead(proxyRes.statusCode, h);
      proxyRes.pipe(res);
    });
    proxy.on('error', () => {
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'API unavailable' }));
    });
    req.pipe(proxy);
    return;
  }

  // Static files
  const filePath = path.join(FRONTEND_DIR, req.url === '/' ? '/index.html' : req.url);
  fs.stat(filePath, (err, stats) => {
    if (!err && stats.isFile()) {
      const ext = path.extname(filePath).toLowerCase();
      fs.readFile(filePath, (e, data) => {
        if (e) { notFound(res); return; }
        res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
        res.end(data);
      });
    } else {
      // SPA fallback
      const idx = path.join(FRONTEND_DIR, 'index.html');
      fs.readFile(idx, (e, data) => {
        if (e) { notFound(res); return; }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
      });
    }
  });
});

function notFound(res) {
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('404 Not Found');
}

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n✅ Server running on port ${PORT}`);
  console.log(`   → http://localhost:${PORT}`);
  console.log(`   → http://localhost:${PORT}/api`);
  console.log(`   → http://localhost:${PORT}/health\n`);
});

const shutdown = () => {
  console.log('Shutting down...');
  apiProcess.kill('SIGTERM');
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 8000);
};
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);